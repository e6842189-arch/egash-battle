# EGASH BATTLE — Telegram bot

A starter Telegram game bot with:
- Player profiles and coins
- Daily reward
- Brainrot-style character collection (original generic character names)
- Turn-based PvP challenges
- Leaderboard

## 1. Requirements
- Python 3.11+
- A Telegram bot token from @BotFather
- A host that can run a persistent Python process

## 2. Run locally
1. Install Python.
2. Copy `.env.example` to `.env`.
3. Put your NEW bot token in `.env` as `BOT_TOKEN=...`.
4. Install dependencies:
   `pip install -r requirements.txt`
5. Start:
   `python -m app.bot`

Do not share your bot token or upload `.env` to GitHub.

## 3. Deploy
Use a Python hosting service that supports a persistent worker/process.
Set the environment variable `BOT_TOKEN` in the host's dashboard, then run:
`python -m app.bot`

This project uses long polling, so do not run two copies of the bot at once.

## Commands
- `/start` — open the game menu
- `/profile` — your profile
- `/daily` — claim daily coins
- `/collection` — view your characters
- `/battle` — find a random opponent
- `/top` — leaderboard
- `/help` — commands

## Notes
This is a starter version, not a clone of another bot's private code or artwork. Character names and gameplay are original placeholders. The bot must be running on a host to respond.
