import asyncio
import os
import random
import sqlite3
from datetime import date
from pathlib import Path

from aiogram import Bot, Dispatcher, F
from aiogram.filters import Command, CommandStart
from aiogram.types import Message, CallbackQuery
from aiogram.utils.keyboard import InlineKeyboardBuilder
from dotenv import load_dotenv

load_dotenv()
TOKEN = os.getenv("BOT_TOKEN", "").strip()
DB_PATH = Path(__file__).resolve().parent.parent / "egash_battle.db"

CHARACTERS = [
    ("Brr Brr", 20, 45),
    ("Cappuccino Ninja", 35, 60),
    ("Turbo Gator", 50, 80),
    ("Cosmo Cactus", 70, 100),
    ("Neon Raccoon", 90, 125),
]

def connect():
    con = sqlite3.connect(DB_PATH)
    con.row_factory = sqlite3.Row
    return con

def init_db():
    with connect() as con:
        con.execute("""
            CREATE TABLE IF NOT EXISTS players (
                user_id INTEGER PRIMARY KEY,
                username TEXT NOT NULL,
                coins INTEGER NOT NULL DEFAULT 100,
                wins INTEGER NOT NULL DEFAULT 0,
                losses INTEGER NOT NULL DEFAULT 0,
                last_daily TEXT NOT NULL DEFAULT ''
            )
        """)
        con.execute("""
            CREATE TABLE IF NOT EXISTS collection (
                user_id INTEGER NOT NULL,
                character TEXT NOT NULL,
                count INTEGER NOT NULL DEFAULT 1,
                PRIMARY KEY (user_id, character)
            )
        """)

def ensure_player(user_id, username):
    display = username or f"Player{user_id}"
    with connect() as con:
        con.execute(
            "INSERT INTO players(user_id, username) VALUES(?, ?) "
            "ON CONFLICT(user_id) DO UPDATE SET username=excluded.username",
            (user_id, display)
        )

def get_player(user_id):
    with connect() as con:
        return con.execute("SELECT * FROM players WHERE user_id=?", (user_id,)).fetchone()

def main_keyboard():
    kb = InlineKeyboardBuilder()
    kb.button(text="👤 Профиль", callback_data="profile")
    kb.button(text="🎁 Ежедневная награда", callback_data="daily")
    kb.button(text="🧠 Коллекция", callback_data="collection")
    kb.button(text="⚔️ Битва", callback_data="battle")
    kb.button(text="🏆 Топ игроков", callback_data="top")
    kb.adjust(2, 2, 1)
    return kb.as_markup()

async def profile_text(user_id):
    p = get_player(user_id)
    with connect() as con:
        count = con.execute(
            "SELECT COALESCE(SUM(count),0) AS n FROM collection WHERE user_id=?",
            (user_id,)
        ).fetchone()["n"]
    return (
        f"👤 <b>{p['username']}</b>\n"
        f"🪙 Монеты: <b>{p['coins']}</b>\n"
        f"🏆 Победы: <b>{p['wins']}</b>\n"
        f"💥 Поражения: <b>{p['losses']}</b>\n"
        f"🧠 Персонажей собрано: <b>{count}</b>"
    )

async def claim_daily(user_id):
    today = date.today().isoformat()
    with connect() as con:
        row = con.execute("SELECT last_daily FROM players WHERE user_id=?", (user_id,)).fetchone()
        if row["last_daily"] == today:
            return False, 0
        reward = random.randint(50, 100)
        con.execute(
            "UPDATE players SET coins=coins+?, last_daily=? WHERE user_id=?",
            (reward, today, user_id)
        )
    return True, reward

async def collection_text(user_id):
    with connect() as con:
        rows = con.execute(
            "SELECT character, count FROM collection WHERE user_id=? ORDER BY count DESC, character",
            (user_id,)
        ).fetchall()
    if not rows:
        return "🧠 <b>Твоя коллекция пуста.</b>\nВыиграй персонажа в битве, чтобы начать собирать коллекцию!"
    return "🧠 <b>Твоя коллекция</b>\n" + "\n".join(
        f"• {r['character']} × {r['count']}" for r in rows
    )

async def top_text():
    with connect() as con:
        rows = con.execute(
            "SELECT username, coins, wins FROM players ORDER BY coins DESC, wins DESC LIMIT 10"
        ).fetchall()
    if not rows:
        return "Пока игроков нет. Напиши /start!"
    lines = ["🏆 <b>ТОП EGASH BATTLE</b>"]
    for i, r in enumerate(rows, 1):
        lines.append(f"{i}. {r['username']} — 🪙 {r['coins']} | ⚔️ {r['wins']} побед")
    return "\n".join(lines)

async def run_battle(user_id):
    with connect() as con:
        player = con.execute("SELECT coins FROM players WHERE user_id=?", (user_id,)).fetchone()
        if player["coins"] < 10:
            return "🪙 Для битвы нужно минимум 10 монет. Забери ежедневную награду командой /daily."
        opponent_power = random.randint(25, 100)
        your_power = random.randint(20, 100)
        win = your_power >= opponent_power
        if win:
            reward = random.randint(15, 35)
            char, low, high = random.choice(CHARACTERS)
            con.execute(
                "UPDATE players SET coins=coins+?, wins=wins+1 WHERE user_id=?",
                (reward, user_id)
            )
            con.execute(
                "INSERT INTO collection(user_id, character, count) VALUES(?,?,1) "
                "ON CONFLICT(user_id, character) DO UPDATE SET count=count+1",
                (user_id, char)
            )
            return (
                f"⚔️ <b>Ты победил!</b>\n"
                f"Твоя сила: {your_power} | Сила соперника: {opponent_power}\n"
                f"🪙 Награда: {reward} монет\n"
                f"🧠 Новый персонаж: <b>{char}</b>"
            )
        con.execute(
            "UPDATE players SET coins=MAX(0, coins-10), losses=losses+1 WHERE user_id=?",
            (user_id,)
        )
        return (
            f"⚔️ <b>На этот раз поражение.</b>\n"
            f"Твоя сила: {your_power} | Сила соперника: {opponent_power}\n"
            f"Ты потерял 10 монет. Попробуй ещё раз!"
        )

async def main():
    if not TOKEN or TOKEN == "PUT_YOUR_NEW_BOT_TOKEN_HERE":
        raise SystemExit("Set BOT_TOKEN in .env or your hosting environment before starting.")
    init_db()
    bot = Bot(TOKEN)
    dp = Dispatcher()

    @dp.message(CommandStart())
    async def start(message: Message):
        ensure_player(message.from_user.id, message.from_user.username or message.from_user.first_name)
        await message.answer(
            "🔥 <b>EGASH BATTLE</b>\n\n"
            "Добро пожаловать! Собирай персонажей, получай монеты и сражайся.\n"
            "Нажимай кнопки меню или используй /help.",
            reply_markup=main_keyboard()
        )

    @dp.message(Command("help"))
    async def help_cmd(message: Message):
        await message.answer(
            "<b>Команды EGASH BATTLE</b>\n"
            "/start — меню игры\n/profile — профиль\n/daily — ежедневная награда\n"
            "/collection — коллекция\n/battle — битва с виртуальным соперником\n/top — рейтинг"
        )

    @dp.message(Command("profile"))
    async def profile(message: Message):
        ensure_player(message.from_user.id, message.from_user.username or message.from_user.first_name)
        await message.answer(await profile_text(message.from_user.id), reply_markup=main_keyboard())

    @dp.message(Command("daily"))
    async def daily(message: Message):
        ensure_player(message.from_user.id, message.from_user.username or message.from_user.first_name)
        ok, reward = await claim_daily(message.from_user.id)
        if ok:
            await message.answer(f"🎁 Ты получил <b>{reward} монет</b>! Возвращайся завтра.")
        else:
            await message.answer("⏳ Ты уже забрал награду сегодня. Загляни завтра!")

    @dp.message(Command("collection"))
    async def collection(message: Message):
        ensure_player(message.from_user.id, message.from_user.username or message.from_user.first_name)
        await message.answer(await collection_text(message.from_user.id))

    @dp.message(Command("battle"))
    async def battle(message: Message):
        ensure_player(message.from_user.id, message.from_user.username or message.from_user.first_name)
        await message.answer(await run_battle(message.from_user.id))

    @dp.message(Command("top"))
    async def top(message: Message):
        ensure_player(message.from_user.id, message.from_user.username or message.from_user.first_name)
        await message.answer(await top_text())

    @dp.callback_query(F.data == "profile")
    async def cb_profile(call: CallbackQuery):
        ensure_player(call.from_user.id, call.from_user.username or call.from_user.first_name)
        await call.message.answer(await profile_text(call.from_user.id))
        await call.answer()

    @dp.callback_query(F.data == "daily")
    async def cb_daily(call: CallbackQuery):
        ensure_player(call.from_user.id, call.from_user.username or call.from_user.first_name)
        ok, reward = await claim_daily(call.from_user.id)
        await call.message.answer(f"🎁 Ты получил <b>{reward} монет</b>!" if ok else "⏳ Награду можно получить только раз в день.")
        await call.answer()

    @dp.callback_query(F.data == "collection")
    async def cb_collection(call: CallbackQuery):
        ensure_player(call.from_user.id, call.from_user.username or call.from_user.first_name)
        await call.message.answer(await collection_text(call.from_user.id))
        await call.answer()

    @dp.callback_query(F.data == "battle")
    async def cb_battle(call: CallbackQuery):
        ensure_player(call.from_user.id, call.from_user.username or call.from_user.first_name)
        await call.message.answer(await run_battle(call.from_user.id))
        await call.answer()

    @dp.callback_query(F.data == "top")
    async def cb_top(call: CallbackQuery):
        await call.message.answer(await top_text())
        await call.answer()

    print("EGASH BATTLE is running...")
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())
